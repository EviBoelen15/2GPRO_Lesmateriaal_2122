﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Voorbeeldexamen
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            Student s;
            Vak vk;
            OpenFileDialog ofd = new OpenFileDialog
            {
                Filter = "Alle bestanden (*.*)|*.*|Tekstbestanden (*.txt)|*.txt",
                FileName = "Studenten_toepassing.csv",
                Multiselect = true,
                InitialDirectory = System.IO.Path.GetFullPath(@"..\..\Bestanden"), // volledig pad
            };
            if (ofd.ShowDialog() == true)
            {
                Databank.DataFolder = System.IO.Path.GetDirectoryName(ofd.FileName);
                string[] kolommen;
                using (StreamReader sr = new StreamReader(ofd.FileName))
                {
                    while (!sr.EndOfStream)
                    {
                        //Scheidingsteken opgeven, geeft array terug gescheiden door opgegeven karakter.
                        kolommen = sr.ReadLine().Split(';');
                        //Geeft kolommen met gegevens door aan klasse Student
                        s = new Student(kolommen);
                        // Voegt aan klasse Databank de List van studenten toe.
                        Databank.ListStudenten.Add(s);
                    }
                    LstStudent.ItemsSource = Databank.ListStudenten;
                }
            }
            // Vakken vullen
            foreach (var item in Databank.DictVakken)
            {
                vk = new Vak(item.Key, item.Value);
            }
        }

        private void LstStudent_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int index = LstStudent.SelectedIndex;
            MessageBox.Show($"{Databank.ListStudenten[index].Voornaam.Substring(0, 1)}. {Databank.ListStudenten[index].Naam} volgt les in de afdeling {Databank.ListStudenten[index].VakVolledig.ToUpper()}", "Info student");
        }

        private void MenuCSV_Click(object sender, RoutedEventArgs e)
        {
            SaveFileDialog sfd = new SaveFileDialog
            {
                Filter = "Alle bestanden (*.*)|*.*|Tekstbestanden (*.csv)|*.csv",
                FilterIndex = 2,
                Title = "Geef een bestandsnaam op",
                OverwritePrompt = true, //Bevestiging wordt gevraagd bij overschrijven van een bestand.
                AddExtension = true, // Extensie wordt toegevoegd
                InitialDirectory = Databank.DataFolder
            };
            if (sfd.ShowDialog() == true)
            {
                using (StreamWriter sw = new StreamWriter(sfd.FileName))
                {
                    foreach (Student stud in Databank.ListStudenten)
                    {
                        sw.WriteLine($"{stud.Naam};{stud.Voornaam};{stud.VakVolledig}");
                    }
                }
            }
        }

        private void MenuData_Click(object sender, RoutedEventArgs e)
        {
            if (Databank.DataFolder != string.Empty)
            {
                string dataBestand = $"{ Databank.DataFolder}\\data.xml";
                Databank.DsStudent.WriteXml(dataBestand);
            }
        }
        private void MenuOverzicht_Click(object sender, RoutedEventArgs e)
        {
            DataOverzicht dWin = new DataOverzicht();
            dWin.ShowDialog();
        }
    }
}
