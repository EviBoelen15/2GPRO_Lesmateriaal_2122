﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS_WPF_Example_3
{
    public static class Data
    {
        public static string Tekst = string.Empty;
    }
}
