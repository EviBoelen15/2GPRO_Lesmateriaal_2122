﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS_Oefening_05
{
    public static class Wachtwoorden
    {
        public static List<string> Engels = new List<string>();
        public static List<string> Nederlands = new List<string>();
    }
}
