﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibraryBewerking
{
    public class Bewerking
    {
        public float Som(float x, float y)
        {
            return x + y;
        }

        public float Min(float x, float y)
        {
            return x - y;
        }

        public float Maal(float x, float y)
        {
            return x * y;
        }
    }
}
