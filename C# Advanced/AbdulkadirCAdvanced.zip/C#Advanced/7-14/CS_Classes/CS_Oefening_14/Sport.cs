﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS_Oefening_14
{
    public class Sport
    {
        public string Code { get; set; }
        public string Omschrijving { get; set; }
        public double Prijs { get; set; }
    }
}
