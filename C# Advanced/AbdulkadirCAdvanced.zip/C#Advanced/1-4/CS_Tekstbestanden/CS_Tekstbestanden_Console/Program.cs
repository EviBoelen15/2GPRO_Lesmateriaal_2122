﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Win32;

namespace CS_Tekstbestanden_Console
{
    class Program
    {
        static void Main(string[] args)
        {
            



            Console.ReadLine();
        }
    }
}
