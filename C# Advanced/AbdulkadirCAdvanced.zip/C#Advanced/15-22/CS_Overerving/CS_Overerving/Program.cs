﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using ClassLibrary;

namespace CS_Overerving
{
    




    class Program
    {
        static void Main(string[] args)
        {
           

            Console.ReadLine();
        }
    }
}
